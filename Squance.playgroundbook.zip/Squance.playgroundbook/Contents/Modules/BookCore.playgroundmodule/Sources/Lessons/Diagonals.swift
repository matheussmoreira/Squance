//
//  Diagonals.swift
//  BookCore
//
//  Created by Matheus S. Moreira on 15/04/21.
//

import SwiftUI

public struct Diagonals: View {
    // MARK: - PROPERTIES
    @State private var selectedValue = 0
    @State private var values: [Int] = []
    @State private var showAlert = true
    
    public var body: some View {
        ZStack {
            Gradient.radialGrayBlack
            
            
            // MARK: - MATRIX
            HStack(spacing: StandartMatrix.spacing) {
                ForEach(Range(1...StandartMatrix.width)) { col in
                    VStack(spacing: StandartMatrix.spacing) {
                        ForEach(Range(1...StandartMatrix.height)) { row in
                            
                            // CELLS OF THE SQUARE
                            
                            if StandartMatrix.isDrawingSquare(at: (col,row)) {
                                if colorfulCellIsOn(at: (col,row)) {
                                    Cells.ColorfulCell(ofColor: getColorForDiagonal(at: (col,row)), size: .standart)
                                } else {
                                    Cells.RingCell(size: .standart)
                                }
                            }
                            
                            // INDEX CELLS
                            else if StandartMatrix.isDrawingHIndexes(at: (col,row)) {
                                Cells.IndexCell(number: col-3, isOn: indexCellIsOn(at: (col,row)))
                            }
                            else if StandartMatrix.isDrawingVIndexes(at: (col,row)) {
                                Cells.IndexCell(number: row-4, isOn: indexCellIsOn(at: (col,row)))

                            // BACKGROUND CELLS
                            } else {
                                Cells.BackgroundCell(size: .standart)
                            }

                        }
                    }
                }
            } // Matrix
            
            VStack {
                // MARK: - SQUARED NUMBER
                HStack {
                    Text("\(selectedValue)")
                        .font(.system(size: 40))
                        .foregroundColor(.white)
                        .padding(.leading)
                    
                    Text("2")
                        .font(.system(size: 20))
                        .fontWeight(.medium)
                        .foregroundColor(.white)
                        .offset(x: -5, y: -10)
                }.offset(y: 85)
                
                Spacer()
                
                // MARK: - SEQUENCE 1
                HStack {
                    ForEach(values, id: \.self) { value in
                        Cells.SequenceCell(
                            number: getNumberInSequence(from: value),
                            color: Color.ofCells[value-1])
                        
                        if value != values.last {
                            Text("+")
                                .foregroundColor(.white)
                                .font(.subheadline)
                                .fontWeight(.medium)
                        }
                    }
                }.offset(y: -20)
                
                // MARK: - SEQUENCE 2
                HStack {
                    ForEach(values, id: \.self) { value in
                        if value != values.last {
                            Cells.SequenceCell(
                                number: getNumberInSequence(from: value),
                                color: Color.ofCells[value-1])
                            
                            if value != values[values.count-2] {
                                Text("+")
                                    .foregroundColor(.white)
                                    .font(.subheadline)
                                    .fontWeight(.medium)
                            }
                            
                        }
                    }
                }.offset(y: -20)
                
                HStack {
                    // MARK: - ANSWER
                    Text("\(selectedValue*selectedValue)")
                        .font(.system(size: 30))
                        .fontWeight(.medium)
                        .foregroundColor(.white)
                    
                    Cells.ColorfulCell(size: .standart)
                    
                    Spacer()
                    
                    // MARK: - CUSTOM STEPPER
                    // I'm using this over the native Stepper 'cause this way I can see the animations working
                    HStack {
                        Button(action: { withAnimation(.easeOut) { decrementValue() } }) {
                            Text(" -")
                                .foregroundColor(.black)
                                .font(.largeTitle)
                                .frame(width: 55, height: 40)
                                .offset(x: 5)
                        }
                        
                        Divider()
                        
                        Button(action: { withAnimation(.easeOut) { incrementValue() } }) {
                            Text("+ ")
                                .foregroundColor(.black)
                                .font(.largeTitle)
                                .frame(width: 55, height: 40)
                                .offset(x: -5)
                        }
                        
                    }
                    .frame(width: 110, height: 40)
                    .background(Color.white)
                    .cornerRadius(10)
                }.padding() // HStack
            }.animation(.easeOut) // VStack
        }.frame(maxHeight: 910)
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("Now, use the stepper to change the value"),
                dismissButton: .default(Text("Got it!"))
            )
        }
    } // Body
    
    // MARK: - METHODS
    public init(){}
    private func getColorForDiagonal(at position: (Int,Int)) -> Color? {
        let colInSquare = position.0 - 3
        let rowInSquare = position.1 - 4
        
        if colInSquare+rowInSquare-1 <= selectedValue {
            // Upper left half of the square
            // Sum of the distances between the position and the left and upper sides
            let idx = colInSquare-1 + rowInSquare-1
            return Color.ofCells[idx]
        }
        // Lower right half of the square
        // Sum of the distances between the position and the right and lower sides
        let idx = selectedValue-colInSquare + selectedValue-rowInSquare
        return Color.ofCells[idx]
    }
}

// MARK: - MATRIX COORDINATOR
extension Diagonals: MatrixCoordinator {
    public func colorfulCellIsOn(at position: (Int, Int)) -> Bool {
        let colInSquare = position.0 - 3
        let rowInSquare = position.1 - 4
        return colInSquare <= selectedValue && rowInSquare <= selectedValue
    }
    
    public func indexCellIsOn(at position: (Int, Int)) -> Bool {
        let col = position.0
        let row = position.1
        return selectedValue == 0 || colorfulCellIsOn(at: (col,row))
    }
}

// MARK: - SEQUENCE COORDINATOR
extension Diagonals: SequenceCoordinator {
    public func incrementValue() {
        if selectedValue < 10 {
            selectedValue += 1
            values.append(selectedValue)
            //speak()
        }
    }
    
    public func decrementValue() {
        if selectedValue > 0 {
            selectedValue -= 1
            values.removeLast()
            //speak()
        }
    }
    
    public func getNumberInSequence(from index: Int) -> Int {
        return index // Sequence: 1, 2, ..., 9, 10
    }
}
