//
//  FibonacciHint.swift
//  BookCore
//
//  Created by Matheus S. Moreira on 16/04/21.
//

import SwiftUI

public struct FibonacciHint : View {
    var values: [Int]
    private var stackHeight: CGFloat = 430
    private let yOffset: CGFloat = -18
    
    public init(values: [Int]) {
        self.values = values
    }
    
    public var body: some View {
        if values.isEmpty {
            RectangleFibonacciHint(number: 0)
                .offset(y: yOffset)
        } else {
            HStack {
                if values.contains(13) {
                    RectangleFibonacciHint(number: 13).offset(x: -3)
                } else {
                    Spacer()
                }
                
                VStack {
                    if values.contains(8) {
                        RectangleFibonacciHint(number: 8)
                    } else {
                        Spacer()
                    }
                    
                    HStack {
                        VStack {
                            HStack {
                                if values.contains(2) {
                                    RectangleFibonacciHint(number: 2)
                                        .frame(width: 55)
                                        .offset(x: -3)
                                } else {
                                    Spacer()
                                }
                                VStack {
                                    if values.count > 1 {
                                        RectangleFibonacciHint(number: 1)
                                            .frame(width: 28, height: 28)
                                            .offset(x: values.contains(2) ? 0 : -5)
                                    } else {
                                        Spacer()
                                    }
                                    
                                    RectangleFibonacciHint(number: 1)
                                        .frame(width: 28, height: 28)
                                        .offset(x: values.contains(2) ? 0 : -5)
                                }
                            }
                            .frame(height: 60)
                            
                            if values.contains(3) {
                                RectangleFibonacciHint(number: 3)
                                    .frame(width: 85)
                                    .offset(x: -3)
                            } else {
                                Spacer()
                            }
                        }.frame(width: 100)
                        
                        if values.contains(5) {
                            RectangleFibonacciHint(number: 5)
                        } else {
                            Spacer()
                        }
                    }.frame(height: 155)
                }
                .frame(width: 260, height: stackHeight)
                .offset(x: 5)
            }
            .frame(width: 700, height: stackHeight)
            .padding(.horizontal)
            .offset(y: yOffset)
        }
    }
}
public struct RectangleFibonacciHint : View {
    @State private var strokeWidth: CGFloat = 0
    @State private var cornerRadius: CGFloat = 0
    @State private var textSize: Font = .body
    var number: Int
    
    public var body: some View {
        if number == 0 {
            ZStack {
                RoundedRectangle(cornerRadius: 20)
                    .foregroundColor(.fibonacciHint)
                
                RoundedRectangle(cornerRadius: 20)
                    .stroke(Color.white, lineWidth: 5)
                
                Text("Increment at least one value")
                    .foregroundColor(.white)
                    .font(.title)
            }
            .frame(width: 700, height: 430)
            
        } else {
            ZStack {
                RoundedRectangle(cornerRadius: cornerRadius)
                    .foregroundColor(.fibonacciHint)
                
                RoundedRectangle(cornerRadius: cornerRadius)
                    .stroke(Color.white, lineWidth: strokeWidth)
                
                Text(getText())
                    .foregroundColor(.white)
                    .font(textSize)
                    .fontWeight(.medium)
            }.onAppear { sizeSetup() }
        }
        
        
    }
    
    private func sizeSetup() {
        switch number {
            case 13:
                strokeWidth = 5
                cornerRadius = 20
                textSize = .system(size: 40)
            case 8:
                strokeWidth = 5
                cornerRadius = 20
                textSize = .system(size: 30)
            case 5:
                strokeWidth = 4
                cornerRadius = 15
                textSize = .system(size: 25)
            case 3:
                strokeWidth = 4
                cornerRadius = 10
                textSize = .system(size: 15)
            default:
                strokeWidth = 3
                cornerRadius = 5
                textSize = .system(size: 10)
        }
    }
    private func getText() -> String {
        if number == 1 {
            return "1"
        } else {
            return "\(number) x \(number)"
        }
    }
}
