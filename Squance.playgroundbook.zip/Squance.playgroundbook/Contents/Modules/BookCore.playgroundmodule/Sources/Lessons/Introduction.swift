//
//  Introduction.swift
//  BookCore
//
//  Created by Matheus S. Moreira on 16/04/21.
//

import SwiftUI

public struct Introduction: View, MatrixCoordinator {
    public var body: some View {
        ZStack {
            Gradient.radialGrayBlack
            
            // MARK: - MATRIX
            HStack(spacing: StandartMatrix.spacing) {
                ForEach(Range(1...StandartMatrix.width)) { col in
                    VStack(spacing: StandartMatrix.spacing) {
                        ForEach(Range(1...StandartMatrix.height)) { row in
                            if StandartMatrix.isDrawingSquareForIntro(at: (col,row)) {
                                Cells.ColorfulCell(size: .standart)
                            } else if StandartMatrix.isDrawingHIndexesForIntro(at: (col,row)) {
                                Cells.IndexCell(number: col-3, isOn: indexCellIsOn(at: (col,row)))
                            } else if StandartMatrix.isDrawingVIndexesForIntro(at: (col,row)) {
                                Cells.IndexCell(number: row-4, isOn: indexCellIsOn(at: (col,row)))
                            } else {
                                Cells.BackgroundCell(size: .standart)
                            }
                        }
                    }
                }
            } // Matrix
            
            VStack {
                Image("TITLE")
                    .resizable()
                    .frame(width: 312, height: 100)
                    .offset(y: 120)
                Spacer()
            }
        }.frame(maxHeight: 910) // ZStack
    } // Body
    
    // MARK: - METHODS
    public init(){}
    
    public func colorfulCellIsOn(at position: (Int, Int)) -> Bool {
        let col = position.0
        let row = position.1
        return (4...13).contains(col) && (5...14).contains(row)
    }
    
    public func indexCellIsOn(at position: (Int, Int)) -> Bool {
        return true
    }
    
    public func speak() {
    }
}

