//
//  Fibonacci.swift
//  BookCore
//
//  Created by Matheus S. Moreira on 15/04/21.
//

import SwiftUI

public struct Fibonacci: View {
    // MARK: - PROPERTIES
    @State private var selectedValue = 0
    @State private var values: [Int] = []
    @State private var cellsOnCount = 0
    @State private var answer = 0
    @State private var showHint = false
    
    public init(){}
    
    public var body: some View {
        ZStack {
            Gradient.radialGrayBlack
            
            // MARK: - MATRIX
            HStack(spacing: FibonacciMatrix.spacing) {
                ForEach(Range(1...FibonacciMatrix.width)) { col in
                    VStack(spacing: FibonacciMatrix.spacing) {
                        ForEach(Range(1...FibonacciMatrix.height)) { row in
                            
                            // CELLS OF THE SQUARE
                            if FibonacciMatrix.isDrawingSpiral(at: (col,row)) {
                                if colorfulCellIsOn(at: (col,row)) {
                                    Cells.ColorfulCell(ofColor: getColor(at: (col,row)), size: .small)
                                } else {
                                    Cells.RingCell(size: .small)
                                }
                                
                            // BACKGROUND CELLS
                            } else {
                                Cells.BackgroundCell(size: .small)
                            }
                        }
                    }
                }
            } // Matrix
            
            if showHint {
                FibonacciHint(values: values)
                    .animation(.easeOut)
            }
            
            VStack {
                Spacer()
                
                if !values.isEmpty && showHint {
                    Text("The number 0 is omitted")
                        .foregroundColor(.white)
                        .font(.title)
                        .fontWeight(.medium)
                        .italic()
                        .offset(y: -30)
                }
                
                
                // MARK: - SEQUENCE
                HStack {
                    ForEach(0..<values.count, id: \.self) { idx in
                        ZStack { // Colorful ball w/ squared number
                            Circle()
                                .frame(width: 45, height: 45)
                                .foregroundColor(getColorForSequence(at: idx))
                            
                            Text("\(getNumberInSequence(from: values[idx]))")
                                .font(.title3)
                                .fontWeight(.medium)
                                .foregroundColor(.black)
                        }
                        
                        if canWritePlusText(idx: idx) {
                            Text("+")
                                .foregroundColor(.white)
                                .font(.title)
                                .fontWeight(.medium)
                        }
                    }
                }.offset(y: -20)
                
                HStack {
                    // MARK: - ANSWER
                    Text("\(answer)")
                        .font(.system(size: 30))
                        .fontWeight(.medium)
                        .foregroundColor(.white)
                    
                    Cells.ColorfulCell(size: .standart)
                    
                    // MARK: - HIGHLIGHTED CIRCLES
                    Text("\(cellsOnCount)")
                        .font(.system(size: 30))
                        .fontWeight(.medium)
                        .foregroundColor(.white)
                    
                    VStack {
                        HStack {
                            Circle().foregroundColor(Color.ofCells[0])
                                .frame(width: 15, height: 15)
                                .offset(x: 2)
                            Circle().foregroundColor(Color.ofCells[1])
                                .frame(width: 15, height: 15)
                                .offset(x: -2)
                        }.offset(y: 2)
                        HStack {
                            Circle().foregroundColor(Color.ofCells[2])
                                .frame(width: 15, height: 15)
                                .offset(x: 2)
                            Circle().foregroundColor(Color.ofCells[3])
                                .frame(width: 15, height: 15)
                                .offset(x: -2)
                        }.offset(y: -2)
                    }
                    
                    Spacer()
                    
                    // MARK: - HINT
                    Button(action: { self.showHint.toggle()} ) {
                        ZStack {
                            Circle()
                                .foregroundColor(.white)
                                .frame(width: 40, height: 40)
                            
                            Text("?")
                                .font(.title)
                                .fontWeight(.medium)
                                .foregroundColor(.black)
                        }
                    }
                    
                    
                    // MARK: - CUSTOM STEPPER
                    // I'm using this over the native Stepper 'cause this way I can see the animations working
                    HStack {
                        Button(action: { withAnimation(.easeOut) { decrementValue() } }) {
                            Text(" -")
                                .foregroundColor(.black)
                                .font(.largeTitle)
                                .frame(width: 55, height: 40)
                                .offset(x: 5)
                        }
                        
                        Divider()
                        
                        Button(action: { withAnimation(.easeOut) { incrementValue() } }) {
                            Text("+ ")
                                .foregroundColor(.black)
                                .font(.largeTitle)
                                .frame(width: 55, height: 40)
                                .offset(x: -5)
                        }
                        
                    }
                    .frame(width: 110, height: 40)
                    .background(Color.white)
                    .cornerRadius(10)
                }.padding() // HStack
            }.animation(.easeOut) // VStack
        }.frame(maxHeight: 910)
    } // Body
    
    private func getColor(at position: (Int,Int)) -> Color {
        let colInSquare = position.0
        let rowInSquare = position.1 - 5
        
        if colInSquare == 16 && (9...10).contains(rowInSquare) {
            return .lightGreen // 1 x 1
        } else if (14...15).contains(colInSquare) && (9...10).contains(rowInSquare) {
            return .lightBlue // 2 x 2
        } else if (14...16).contains(colInSquare) && (11...13).contains(rowInSquare) {
            return .lightPink // 3 x 3
        } else if (17...21).contains(colInSquare) && (9...13).contains(rowInSquare) {
            return .cheddarYellow // 5 x 5
        } else if (14...21).contains(colInSquare) && (1...8).contains(rowInSquare) {
            return .seaGreen // 8 x 8
        } else if (1...13).contains(colInSquare) && (1...13).contains(rowInSquare) {
            return .coolRed // 13 x 13
        } else {
            return Color.darkGray.ofCell
        }
    }
    private func getColorForSequence(at idx: Int) -> Color {
        if values[idx] == 1 {
            return Color.lightGreen
        }
        return Color.ofCells[idx-1]
    }
    private func canWritePlusText(idx: Int) -> Bool {
        return (values.count == 2 && idx == 0) || (values[idx] != values.last)
    }
}

// MARK: - MATRIX COORDINATOR
extension Fibonacci: MatrixCoordinator {
    public func colorfulCellIsOn(at position: (Int, Int)) -> Bool {
        let colInSquare = position.0
        let rowInSquare = position.1 - 5
        
        if colInSquare == 16 && rowInSquare == 10 && selectedValue >= 1 {
            return true // 1 x 1
        } else if colInSquare == 16 && rowInSquare == 9 && selectedValue >= 2 {
            return true // 1 x 1
        } else if (14...15).contains(colInSquare) && (9...10).contains(rowInSquare) && selectedValue >= 3 {
            return true // 2 x 2
        } else if (14...16).contains(colInSquare) && (11...13).contains(rowInSquare) && selectedValue >= 4 {
            return true // 3 x 3
        } else if (17...21).contains(colInSquare) && (9...13).contains(rowInSquare) && selectedValue >= 5 {
            return true // 5 x 5
        } else if (14...21).contains(colInSquare) && (1...8).contains(rowInSquare) && selectedValue >= 6 {
            return true // 8 x 8
        } else if (1...13).contains(colInSquare) && (1...13).contains(rowInSquare) && selectedValue == 7 {
            return true // 13 x 13
        } else {
            return false
        }
    }
    
    public func indexCellIsOn(at position: (Int, Int)) -> Bool {
        return false // This function is not being used in this lesson
    }
    
}

// MARK: - SEQUENCE COORDINATOR
extension Fibonacci: SequenceCoordinator {
    public func incrementValue() {
        if selectedValue < 7 {
            selectedValue += 1
            
            let length = values.count
            
            if length < 2 {
                values.append(1)
                cellsOnCount += 1
                answer += 1
            } else {
                let newValue = values.last!+values[length-2] // sum of the two antecessors
                values.append(newValue)
                cellsOnCount += newValue * newValue
                answer += newValue
            }
        }
    }
    
    public func decrementValue() {
        if selectedValue > 0 {
            selectedValue -= 1
            cellsOnCount -= values.last! * values.last!
            answer -= values.last!
            values.removeLast()
        }
    }
    
    public func getNumberInSequence(from index: Int) -> Int {
        return index // Sequence: 1, 1, 2, 3, 5, 8, 13
    }
    
}
