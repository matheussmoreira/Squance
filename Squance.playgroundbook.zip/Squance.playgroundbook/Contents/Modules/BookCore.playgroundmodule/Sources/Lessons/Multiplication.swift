//
//  Multiplication.swift
//  BookCore
//
//  Created by Matheus S. Moreira on 15/04/21.
//

import SwiftUI

public struct Multiplication: View {
    // MARK: - PROPERTIES
    @State private var values: [(Int,Int)] = []
    @State private var selectedColumn = 0
    @State private var selectedRow = 0
    @State private var showHint = false
    @State private var showAlert = true
    
    private var selectedColumnInSquare: Int {
        let col = selectedColumn - 3
        return col < 0 ? 0 : col
    }
    
    private var selectedRowInSquare: Int {
        let row = selectedRow - 4
        return row < 0 ? 0 : row
    }
    
    private var selectedPosition: (Int, Int) {
        return (selectedColumn, selectedRow)
    }
    
    public var body: some View {
        ZStack {
            Gradient.radialGrayBlack
            
            // MARK: - MATRIX
            HStack(spacing: StandartMatrix.spacing) {
                ForEach(Range(1...StandartMatrix.width)) { col in
                    VStack(spacing: StandartMatrix.spacing) {
                        ForEach(Range(1...StandartMatrix.height)) { row in
                            
                            // CELL OF THE SQUARE
                            if StandartMatrix.isDrawingSquare(at: (col,row)) {
                                if colorfulCellIsOn(at: (col,row)) {
                                    if showHint {
                                        Cells.ColorfulCell(size: .standart, numbers: (col-3,row-4))
                                            .onTapGesture {
                                                withAnimation(.easeOut) {
                                                    updateSelectedPosition(to: (col,row))
                                                }
                                            }
                                    } else {
                                        Cells.ColorfulCell(size: .standart)
                                            .onTapGesture {
                                                withAnimation(.easeOut) {
                                                    updateSelectedPosition(to: (col,row))
                                                }
                                            }
                                    }
                                } else {
                                    if showHint {
                                        Cells.RingCell(size: .standart, numbers: (col-3,row-4))
                                            .onTapGesture {
                                                withAnimation(.easeOut)  {
                                                    updateSelectedPosition(to: (col,row))
                                                }
                                            }
                                    } else {
                                        Cells.RingCell(size: .standart)
                                            .onTapGesture {
                                                withAnimation(.easeOut)  {
                                                    updateSelectedPosition(to: (col,row))
                                                }
                                            }
                                    }
                                    
                                }
                            }
                            
                            // INDEX CELLS
                            else if (col == 3 && row == 4) {
                                Cells.IndexCell() // x symbol
                            }
                            else if StandartMatrix.isDrawingHIndexes(at: (col,row)) {
                                Cells.IndexCell(number: col-3, isOn: indexCellIsOn(at: (col,row)))
                            }
                            else if StandartMatrix.isDrawingVIndexes(at: (col,row)) {
                                Cells.IndexCell(number: row-4, isOn: indexCellIsOn(at: (col,row)))
                            } else {
                                // BACKGROUND CELLS
                                Cells.BackgroundCell(size: .standart)
                                    .onTapGesture {
                                        withAnimation(.easeOut)  {
                                            resetSelectedPosition()
                                        }
                                    }
                            }
                        }
                    }
                }
            } // Matrix
            
            VStack {
                // MARK: - MULTIPLICATION
                Text("\(selectedRowInSquare) x \(selectedColumnInSquare)")
                    .font(.system(size: 40))
                    .foregroundColor(.white)
                    .offset(y: 90)
                
                Spacer()
                
                // MARK: - SEQUENCE
                HStack {
                    ForEach(0..<values.count, id: \.self) { idx in
                        Cells.SequenceCell(number: values[idx].1, color: .lightGreen)
                        
                        if values[idx].0 != values.last!.0 {
                            Text("+")
                                .foregroundColor(.white)
                                .font(.title)
                                .fontWeight(.medium)
                        }
                    }
                }.offset(y: -20)
                
                // MARK: - ANSWER
                HStack {
                    Text("\(selectedRowInSquare*selectedColumnInSquare)")
                        .font(.system(size: 30))
                        .fontWeight(.medium)
                        .foregroundColor(.white)
                        .padding(.leading)
                    
                    Cells.ColorfulCell(size: .standart)
                    
                    Spacer()
                    
                    // MARK: - HINT
                    Button(action: { self.showHint.toggle()} ) {
                        ZStack {
                            Circle()
                                .foregroundColor(.white)
                                .frame(width: 40, height: 40)
                            
                            Text("?")
                                .font(.title)
                                .fontWeight(.medium)
                                .foregroundColor(.black)
                        }
                    }.padding()
                    
                }.padding()
            }.animation(.easeOut)
        }.frame(maxHeight: 910)
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("Tap in any circle to multiply"),
                message: Text("Check the hint to see all the answers"),
                dismissButton: .default(Text("Got it!"))
            )
        }
    } // body
    
    // MARK: - METHODS
    public init(){}
    
    private func updateSelectedPosition(to newPosition: (Int,Int)) {
        selectedColumn = newPosition.0
        selectedRow = newPosition.1
        values = []
        for i in 1...selectedColumnInSquare { values.append((i,selectedRowInSquare)) }
        //speak()
    }
    
    private func resetSelectedPosition(){
        selectedColumn = 0
        selectedRow = 0
        values = []
    }
    
    private func multiplication(_ n1: Int, _ n2: Int) -> Int {
        return (n1-4)*(n2-6)
    }
}

// MARK: - MATRIX COORDINATOR
extension Multiplication: MatrixCoordinator {
    public func colorfulCellIsOn(at position: (Int,Int)) -> Bool {
        let col = position.0
        let row = position.1
        return col <= selectedColumn && row <= selectedRow
    }
    
    public func indexCellIsOn(at position: (Int, Int)) -> Bool {
        let col = position.0
        let row = position.1
        return selectedPosition == (0,0) || colorfulCellIsOn(at: (col,row))
    }
}

