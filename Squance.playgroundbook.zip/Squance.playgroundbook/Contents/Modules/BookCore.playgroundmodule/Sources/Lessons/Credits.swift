//
//  Credits.swift
//  BookCore
//
//  Created by Matheus S. Moreira on 16/04/21.
//

import SwiftUI

public struct Credits: View {
    public init(){}
    public var body: some View {
        ZStack {
            Gradient.radialGrayBlack
            
            // MARK: - MATRIX
            HStack(spacing: StandartMatrix.spacing) {
                ForEach(Range(1...StandartMatrix.width)) { col in
                    VStack(spacing: StandartMatrix.spacing) {
                        ForEach(Range(1...StandartMatrix.height)) { row in
                            if StandartMatrix.isDrawingHeart(at: (col,row)) {
                                Cells.ColorfulCell(ofColor: .coolRed, size: .standart)
                            } else {
                                Cells.BackgroundCell(size: .standart)
                            }
                        }
                    }
                }
            } // Matrix
        }.frame(maxHeight: 910) // ZStack
    } // Body
}
