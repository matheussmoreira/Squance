//
//  ColorSystem.swift
//  BookCore
//
//  Created by Matheus S. Moreira on 15/04/21.
//

import UIKit
import SwiftUI

// MARK: - COLORS & GRADIENTS
public extension Color {
    static let cheddarYellow = Color(#colorLiteral(red: 1, green: 0.8431372549, blue: 0, alpha: 1))
    static let coolOrange = Color(#colorLiteral(red: 1, green: 0.6117647059, blue: 0.02352941176, alpha: 1))
    static let coolPurple = Color(#colorLiteral(red: 0.5607843137, green: 0.1215686275, blue: 1, alpha: 1))
    static let coolRed = Color(#colorLiteral(red: 1, green: 0.3176470588, blue: 0.3176470588, alpha: 1))
    static let elegantBlue = Color(#colorLiteral(red: 0.4078431373, green: 0.537254902, blue: 1, alpha: 1))
    static let fibonacciHint = Color(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.6957628869))
    static let lightBlue = Color(#colorLiteral(red: 0, green: 0.9411764706, blue: 1, alpha: 1))
    static let lightGreen = Color(#colorLiteral(red: 0.5607843137, green: 1, blue: 0, alpha: 1))
    static let lightPink = Color(#colorLiteral(red: 1, green: 0, blue: 0.8980392157, alpha: 1))
    static let lemonGreen = Color(#colorLiteral(red: 0.9411764706, green: 1, blue: 0.5764705882, alpha: 1))
    static let seaGreen = Color(#colorLiteral(red: 0, green: 0.4509803922, blue: 0.4784313725, alpha: 1))
    static let ofCells = [lightGreen, lightBlue, lightPink, cheddarYellow, seaGreen, coolRed, elegantBlue, coolOrange, coolPurple, lemonGreen]
    
    struct darkGray {
        public static let ofCell = Color(#colorLiteral(red: 0.1137254902, green: 0.1137254902, blue: 0.1137254902, alpha: 1))
        public static let ofGradient = Color(#colorLiteral(red: 0.2039215686, green: 0.2039215686, blue: 0.2039215686, alpha: 1))
    }
}

public extension Gradient {
    static let radialGrayBlack = RadialGradient(
        gradient: Gradient(colors: [Color.darkGray.ofGradient, .black]),
        center: .center,
        startRadius: 1,
        endRadius: 600
    )
}
