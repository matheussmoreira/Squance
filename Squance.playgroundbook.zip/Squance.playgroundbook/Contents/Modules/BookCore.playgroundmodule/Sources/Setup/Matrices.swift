//
//  Matrices.swift
//  BookCore
//
//  Created by Matheus S. Moreira on 16/04/21.
//

import SwiftUI

// MARK: - STANDART MATRIX
public struct StandartMatrix {
    public static let width = 15
    public static let height = 18
    public static let spacing: CGFloat = 9.0
    
    public init(){}
    
    public static func isDrawingSquare(at position: (Int,Int)) -> Bool {
        let col = position.0
        let row = position.1
        return ((4...13).contains(col) && (5...14).contains(row))
    }
    
    public static func isDrawingHIndexes(at position: (Int,Int)) -> Bool {
        let col = position.0
        let row = position.1
        return ((4...13).contains(col) && row == 4)
    }
    
    public static func isDrawingVIndexes(at position: (Int,Int)) -> Bool {
        let col = position.0
        let row = position.1
        return (col == 3 && (5...14).contains(row))
    }
    
    public static func isDrawingHeart(at position: (Int,Int)) -> Bool {
        let col = position.0
        let row = position.1
        
        if (col == 2 || col == 14) && (5...9).contains(row) {
            return true
        } else if (col == 3 || col == 13) && (4...10).contains(row) {
            return true
        } else if (col == 4 || col == 12) && (4...11).contains(row) {
            return true
        } else if (col == 5 || col == 11) && (4...12).contains(row) {
            return true
        } else if (col == 6 || col == 10) && (5...13).contains(row) {
            return true
        } else if (col == 7 || col == 9) && (6...14).contains(row) {
            return true
        } else if (col == 8) && (7...15).contains(row) {
            return true
        }
        else {
            return false
        }
    }
}

extension StandartMatrix {
    public static func isDrawingSquareForIntro(at position: (Int,Int)) -> Bool {
        let col = position.0
        let row = position.1
        return ((4...13).contains(col) && (7...16).contains(row))
    }
    
    public static func isDrawingHIndexesForIntro(at position: (Int,Int)) -> Bool {
        let col = position.0
        let row = position.1
        return ((4...13).contains(col) && row == 6)
    }
    
    public static func isDrawingVIndexesForIntro(at position: (Int,Int)) -> Bool {
        let col = position.0
        let row = position.1
        return (col == 3 && (7...16).contains(row))
    }
}

// MARK: - FIBONACCI MATRIX
public struct FibonacciMatrix {
    public static let width = 21
    public static let height = 24
    public static let spacing: CGFloat = 5
    
    public init(){}
    
    public static func isDrawingSpiral(at position: (Int,Int)) -> Bool {
        let row = position.1
        return (6...18).contains(row)
    }
}


