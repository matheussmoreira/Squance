//
//  Cells.swift
//  BookCore
//
//  Created by Matheus S. Moreira on 16/04/21.
//

import SwiftUI

public struct Cells {
    private static let largeWH: CGFloat = 40
    private static let standartWH: CGFloat = 40
    private static let smallWH: CGFloat = 30
    
    public enum Size {
        case large, standart, small
    }
    
    public struct BackgroundCell : View {
        let size: Size
        
        public init(size: Size){
            self.size = size
        }
        
        public var body : some View {
            if size == .standart {
                Circle()
                    .frame(width: Cells.standartWH, height: Cells.standartWH)
                    .foregroundColor(Color.darkGray.ofCell)
            } else {
                Circle()
                    .frame(width: Cells.smallWH, height: Cells.smallWH)
                    .foregroundColor(Color.darkGray.ofCell)
            }
            
        }
    }
    
    public struct ColorfulCell : View {
        let size: Size
        let color: Color
        var numbers: (Int,Int) = (0,0)
        
        public init(size: Size){
            color = .lightGreen
            self.size = size
        }
        
        public init(ofColor color: Color?, size: Size) {
            self.color = color ?? .white
            self.size = size
        }
        
        public init(size: Size, numbers: (Int,Int)) {
            color = .lightGreen
            self.size = size
            self.numbers = numbers
        }
        
        public var body : some View {
            if size == .standart {
                ZStack {
                    Circle()
                        .frame(width: Cells.standartWH, height: Cells.standartWH)
                        .foregroundColor(color)
                    if numbers != (0,0) {
                        Text("\(numbers.0*numbers.1)")
                            .font(.title3)
                            .foregroundColor(.black)
                            .fontWeight(.medium)
                    }
                }
            } else {
                Circle()
                    .frame(width: Cells.smallWH, height: Cells.smallWH)
                    .foregroundColor(color)
            }
            
        }
    }
    
    public struct RingCell : View {
        let size: Size
        var numbers: (Int,Int) = (0,0)
        
        public init(size: Size){
            self.size = size
        }
        
        public init(size: Size, numbers: (Int,Int)){
            self.size = size
            self.numbers = numbers
        }
        
        public var body: some View {
            if size == .standart {
                ZStack {
                    Circle()
                        .frame(width: Cells.standartWH, height: Cells.standartWH)
                        .foregroundColor(.white)
                    
                    Circle()
                        .frame(width: Cells.standartWH-3, height: Cells.standartWH-3)
                        .foregroundColor(Color.darkGray.ofCell)
                    
                    if numbers != (0,0) {
                        Text("\(numbers.0*numbers.1)")
                            .font(.title3)
                            .foregroundColor(.white)
                            .fontWeight(.medium)
                    }
                }
            } else {
                ZStack {
                    Circle()
                        .frame(width: Cells.smallWH, height: Cells.smallWH)
                        .foregroundColor(.white)
                    
                    Circle()
                        .frame(width: Cells.smallWH-3, height: Cells.smallWH-3)
                        .foregroundColor(Color.darkGray.ofCell)
                }
            }
            
        }
    }
    
    public struct IndexCell : View {
        var number: Int
        var isOn: Bool
        var isTimesSymbol: Bool
        let size: Size = .standart
        
        public init(number: Int, isOn: Bool){
            self.number = number
            self.isOn = isOn
            self.isTimesSymbol = false
        }
        
        public init(){
            self.number = 0
            self.isOn = true
            self.isTimesSymbol = true
        }
        
        public var body : some View {
            if isOn {
                ZStack {
                    Circle()
                        .frame(
                            width: Cells.standartWH,
                            height: Cells.standartWH)
                        .foregroundColor(Color(.white))
                    Text(isTimesSymbol ? "X" : "\(number)")
                        .font(.title3)
                        .fontWeight(.medium)
                        .foregroundColor(.black)
                }
            } else {
                ZStack {
                    BackgroundCell(size: size)
                    Text("\(number)")
                        .font(.title3)
                        .fontWeight(.medium)
                        .foregroundColor(.white)
                }
                
            }

        }
    }
    
    public struct SequenceCell : View {
        var number : Int
        var color: Color
        
        public init(number: Int, color: Color) {
            self.number = number
            self.color = color
        }
        
        public var body: some View {
            ZStack {
                Circle()
                    .frame(
                        width: Cells.largeWH,
                        height: Cells.largeWH)
                    .foregroundColor(color)
                Text("\(number)")
                    .font(.title3)
                    .fontWeight(.medium)
                    .foregroundColor(.black)
            }
        }
    }
}
