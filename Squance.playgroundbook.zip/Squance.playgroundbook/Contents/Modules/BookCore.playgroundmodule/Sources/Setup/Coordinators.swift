//
//  Coordinators.swift
//  BookCore
//
//  Created by Matheus S. Moreira on 15/04/21.
//

public protocol MatrixCoordinator {
    func colorfulCellIsOn(at position: (Int,Int)) -> Bool
    func indexCellIsOn(at position: (Int, Int)) -> Bool
}

public protocol SequenceCoordinator {
    func incrementValue()
    func decrementValue()
    func getNumberInSequence(from index: Int) -> Int
}

