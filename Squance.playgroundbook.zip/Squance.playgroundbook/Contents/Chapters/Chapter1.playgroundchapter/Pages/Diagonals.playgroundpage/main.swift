/*:
 ![CoverDiagonals](CoverDiagonals.png)
 # Lesson 2
 Can you guess the result of adding *1+2+...+999+1000+999+...+2+1*?
 
 This seems to be a laborious task to complete, but it's not!
 
 It happens that in math we can identify patterns and use shortcuts to find answers.
 
 **If you add the first N consecutive numbers back and forth, you get Nˆ2!**
 
 - Read this as *N squared*, that means N x N
 
 * Callout(Experiment:):
 To prove this visually, run the code and notice the circles in the diagonals.
 
 Incredible, isn't it?
*/
//#-hidden-code
import SwiftUI
import BookCore
import PlaygroundSupport

PlaygroundPage.current.setLiveView(Diagonals())
//#-end-hidden-code
