/*:
 ![CoverFibonacci](CoverFibon.png)
 # Lesson 3
 Our last sequence is called Fibonacci Sequence, in tribute to the Italian mathematician Leonardo Fibonacci (1170-1250).
 
 In this one, that starts with 0 and 1, **each number equals the sum of their two predecessors.**
 
 Geometrically, they generate a spiral called *golden spiral*, that receives this name because it is a pattern found in several shapes in nature, like flower petals, shells, hurricanes and galaxies.
 
 ![Nature](Nature.png)
 
 Run the code to check it out!
*/
//#-hidden-code
import SwiftUI
import BookCore
import PlaygroundSupport

PlaygroundPage.current.setLiveView(Fibonacci())
//#-end-hidden-code
