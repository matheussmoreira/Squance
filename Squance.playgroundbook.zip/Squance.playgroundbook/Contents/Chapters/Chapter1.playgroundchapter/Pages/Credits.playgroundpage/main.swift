/*:
 ![CoverThanks](CoverThanks.png)
 # Thanks for enjoying the playground!
 
 I hope I convinced you about the power of visual thinking for improving the comprehension of math concepts.
 
 Keep taking care of yourself and let's bring more knowledge to creativity together, for sure this way our lives will be better 😁
 
 ### Credits of the images:
 - [Flower petal](https://unsplash.com/photos/HKGBJ3cbzSs)
 - [Shell](https://unsplash.com/photos/OiMhfg-aeAg)
 - [Hurricane](https://unsplash.com/photos/i9w4Uy1pU-s)
 - [Galaxy](https://unsplash.com/photos/RF4p4rTM-2s)
*/
