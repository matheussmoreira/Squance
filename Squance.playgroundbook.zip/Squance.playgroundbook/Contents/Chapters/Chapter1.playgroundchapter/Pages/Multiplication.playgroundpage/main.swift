/*:
 ![CoverMultiplication](CoverMultip.png)
 # Lesson 1
 Multiplication is a repeated addition of a whole number: A multiplied by B is A added by itself B times.
 
 Usually it is presented in a **times table** like this one:

 ![TimesTable](TimesTable.png)

 * Callout(Question:):
 If multiplication is a sequence of sums, isn't it better when **we can visualize this?**
 
 Well, run the code to conclude by yourself!
*/
//#-hidden-code
import SwiftUI
import BookCore
import PlaygroundSupport

PlaygroundPage.current.setLiveView(Multiplication())
//#-end-hidden-code
